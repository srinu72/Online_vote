function myFunction() 
{
if(location.reload())
{
document.getElementById('user').value="";
document.getElementById('pass').value="";
}
}