<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "sri@123###12";
$dbname = "register";

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve data from the form
$name = $_POST['name'];
$party = $_POST['party'];
$aadhar = $_POST['aadhar'];
$gender = $_POST['gender'];
$address = $_POST['address'];

// Insert data into the database
$sql = "INSERT INTO voter_registrations (name, party, aadhar, gender, address) VALUES ('$name', '$party', '$aadhar', '$gender', '$address')";

if ($conn->query($sql) === TRUE) {
    echo "Registration successful!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the database connection
$conn->close();
?>
