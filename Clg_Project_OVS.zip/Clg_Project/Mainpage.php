<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Voting System</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./fun.css">
</head>
<body>
<div 
class="bold"
style="background-image: url('./pic/Tt.jpg');"
 >
  <div class="color-overlay d-flex justify-content-center align-items-center">
<div class="pic"></div>
    <nav class="fixed-top navbar navbar-expand-sm nav-tabs navbar-light border-1">
        <div class="container">
            <a class=" navbar-brand text-uppercase">Online Voting System</a>
            <div class="div" id="nav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link rounded-3 text-dark" href="/Clg_Project/Mainpage.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-dark" href="#">Admin</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-dark" href="./reg.html">Candidate</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-dark" href="#">Connect Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-dark" href="/Clg_Project/logout.php">Logout</a>
                </li>
            </ul>
        </div>
        </div>
    </nav>
</div>
<div class="mt-5 pt-5 mx-5  text-center">
    <h4>Happy to see You.....!</h4>
</div>

   <div class="container sm-5 px-1">
            <h3> <h3>Welcome to Online Voting system 
         <br>Saving time for your valid vote..</h3>
</div>
</div>
</div>
<script>  
          function login(){
            window.open('/Clg_Project/index.html');
          } 
    function validation()  
    {  
        var id=document.f1.user.value;  
        var ps=document.f1.pass.value;  
        if(id.length=="" && ps.length=="") {  
            alert("User Name and Password fields are empty");  
            return false;  
        }  
        else  
        {  
            if(id.length=="") {  
                alert("User Name is empty");  
                return false;  
            }   
            if (ps.length=="") {  
            alert("Password field is empty");  
            return false;  
            }  
        }                             
    }  
</script>  
<script src="./js/bootstrap.min.js"></script>
<script src="./js/jquery.min.js"></script>
    
</body>
</html>